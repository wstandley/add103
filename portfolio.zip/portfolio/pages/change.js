function change01() {
  document.getElementById("large").src =
    "https://t2.genius.com/unsafe/300x0/https%3A%2F%2Fimages.genius.com%2Fa2de648becefaaa489ece74d5c0926b0.1000x1000x1.png";
}

function change02() {
  document.getElementById("large").src =
    "https://t2.genius.com/unsafe/300x0/https%3A%2F%2Fimages.genius.com%2F6c24e8a9aefba27d00322109f6e46731.1000x1000x1.png";
}

function change03() {
  document.getElementById("large").src =
    "https://t2.genius.com/unsafe/300x0/https%3A%2F%2Fimages.genius.com%2Fde4cdccbbae0fd049dda637295f17bca.1000x1000x1.jpg";
}

function change04() {
  document.getElementById("large").src =
    "https://t2.genius.com/unsafe/300x0/https%3A%2F%2Fimages.genius.com%2F77981e411ef0855dea70b61f07982338.640x640x1.jpg";
}
